vcs -PP fifo_fixture.v
simv

