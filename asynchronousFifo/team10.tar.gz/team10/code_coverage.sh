vcs -PP -cm fsm+line+tgl+cond fifo_fixture.v
simv -cm fsm+line+tgl+cond
urg -dir simv.vdb
cd urgReport
firefox dashboard.html
